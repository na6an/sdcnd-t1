
# Self-Driving Car Engineer Nanodegree

## Deep Learning

## Project: Build a Traffic Sign Recognition Classifier

In this notebook, a template is provided for you to implement your functionality in stages, which is required to successfully complete this project. If additional code is required that cannot be included in the notebook, be sure that the Python code is successfully imported and included in your submission if necessary. 

> **Note**: Once you have completed all of the code implementations, you need to finalize your work by exporting the iPython Notebook as an HTML document. Before exporting the notebook to html, all of the code cells need to have been run so that reviewers can see the final implementation and output. You can then export the notebook by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission. 

In addition to implementing code, there is a writeup to complete. The writeup should be completed in a separate file, which can be either a markdown file or a pdf document. There is a [write up template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) that can be used to guide the writing process. Completing the code template and writeup template will cover all of the [rubric points](https://review.udacity.com/#!/rubrics/481/view) for this project.

The [rubric](https://review.udacity.com/#!/rubrics/481/view) contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this Ipython notebook and also discuss the results in the writeup file.


>**Note:** Code and Markdown cells can be executed using the **Shift + Enter** keyboard shortcut. In addition, Markdown cells can be edited by typically double-clicking the cell to enter edit mode.

---
## Step 0: Load The Data

---

## Step 1: Dataset Summary & Exploration

The pickled data is a dictionary with 4 key/value pairs:

- `'features'` is a 4D array containing raw pixel data of the traffic sign images, (num examples, width, height, channels).
- `'labels'` is a 1D array containing the label/class id of the traffic sign. The file `signnames.csv` contains id -> name mappings for each id.
- `'sizes'` is a list containing tuples, (width, height) representing the original width and height the image.
- `'coords'` is a list containing tuples, (x1, y1, x2, y2) representing coordinates of a bounding box around the sign in the image. **THESE COORDINATES ASSUME THE ORIGINAL IMAGE. THE PICKLED DATA CONTAINS RESIZED VERSIONS (32 by 32) OF THESE IMAGES**

Complete the basic data summary below. Use python, numpy and/or pandas methods to calculate the data summary rather than hard coding the results. For example, the [pandas shape method](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.shape.html) might be useful for calculating some of the summary results. 

### Provide a Basic Summary of the Data Set Using Python, Numpy and/or Pandas

### Include an exploratory visualization of the dataset

Visualize the German Traffic Signs Dataset using the pickled file(s). This is open ended, suggestions include: plotting traffic sign images, plotting the count of each sign, etc. 

The [Matplotlib](http://matplotlib.org/) [examples](http://matplotlib.org/examples/index.html) and [gallery](http://matplotlib.org/gallery.html) pages are a great resource for doing visualizations in Python.

**NOTE:** It's recommended you start with something simple first. If you wish to do more, come back to it after you've completed the rest of the sections. It can be interesting to look at the distribution of classes in the training, validation and test set. Is the distribution the same? Are there more examples of some classes than others?


```python
%matplotlib inline
import random
import matplotlib.pyplot as plt
import numpy as np
from sklearn.utils import shuffle

# Load pickled data
import pickle

# TODO: Fill this in based on where you saved the training and testing data

training_file = 'train.p'
validation_file= 'valid.p'
testing_file = 'test.p'

with open(training_file, mode='rb') as f:
    train = pickle.load(f)
with open(validation_file, mode='rb') as f:
    valid = pickle.load(f)
with open(testing_file, mode='rb') as f:
    test = pickle.load(f)

X_train, y_train, size_train, crd_train = train['features'], train['labels'], train['sizes'], train['coords']
X_valid, y_valid, size_valid, crd_valid = valid['features'], valid['labels'], valid['sizes'], valid['coords']
X_test, y_test, size_test, crd_test = test['features'], test['labels'], test['sizes'], test['coords']

assert len(X_train)==len(y_train)==len(size_train)==len(crd_train)
assert len(X_valid)==len(y_valid)==len(size_valid)==len(crd_valid)
assert len(X_test)==len(y_test)==len(size_test)==len(crd_test)

### Replace each question mark with the appropriate value. 
### Use python, pandas or numpy methods rather than hard coding the results

# TODO: Number of training examples
n_train = len(X_train)

# TODO: Number of validation examples
n_validation = len(X_valid)

# TODO: Number of testing examples.
n_test = len(X_test)

# TODO: What's the shape of an traffic sign image?
image_shape = X_train.shape[1:]

# TODO: How many unique classes/labels there are in the dataset.
n_classes = len(np.unique(y_train))

print("Number of training examples =", n_train)
print("Number of testing examples =", n_test)
print("Image data shape =", image_shape)
print("Number of classes =", n_classes)
print(type(X_train))
print(X_train.shape)
print(y_train.shape)
print(size_train.shape)
print(crd_train.shape)
# print(np.array(X_train).shape)

### Data exploration visualization code goes here.

def gallery(x, fst_n, n):
    stack = np.zeros(x.shape[1:])
    #stack = [[] for row in range(x.shape[1])]
    for j in range(n):
        stack = np.concatenate((stack, x[fst_n+j]), axis=1)
    for i in range(n):
        #print(fst_n+i, end=" ")
        print(y_test[fst_n+i], end=" ")
    plt.imshow(stack)

gallery(X_test, 1, 7)

count=[]
for i in range(0, n_classes):
    count.append(len(X_train[y_train == i]))

plt.figure(figsize=(8, 3))
plt.bar(range(0, n_classes), count)
plt.title("Count of Each Sign")
plt.xlabel("Class")
```

    Number of training examples = 34799
    Number of testing examples = 12630
    Image data shape = (32, 32, 3)
    Number of classes = 43
    <class 'numpy.ndarray'>
    (34799, 32, 32, 3)
    (34799,)
    (34799, 2)
    (34799, 4)
    1 38 33 11 38 18 12 




    <matplotlib.text.Text at 0x7fd7d39a3358>




![png](output_6_2.png)



![png](output_6_3.png)



```python
u_idx = []
for i in range(n_classes):
    j=0
    while (y_test[j] != i and j < len(X_test)):
        j += 1 
    u_idx.append(j)

print(u_idx)
stack = []
for i in range(len(u_idx)):
    stack.append(X_test[u_idx[i]])
    
i = random.randint(0, len(u_idx))
print(i)
plt.imshow(stack[i])
```

    [243, 1, 34, 23, 14, 30, 129, 11, 39, 15, 27, 4, 7, 26, 93, 52, 0, 31, 6, 235, 17, 16, 88, 12, 44, 8, 57, 18, 69, 117, 41, 194, 95, 3, 32, 9, 130, 830, 2, 277, 137, 140, 315]
    28





    <matplotlib.image.AxesImage at 0x7fd7d3804780>




![png](output_7_2.png)


----

## Step 2: Design and Test a Model Architecture

Design and implement a deep learning model that learns to recognize traffic signs. Train and test your model on the [German Traffic Sign Dataset](http://benchmark.ini.rub.de/?section=gtsrb&subsection=dataset).

The LeNet-5 implementation shown in the [classroom](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) at the end of the CNN lesson is a solid starting point. You'll have to change the number of classes and possibly the preprocessing, but aside from that it's plug and play! 

With the LeNet-5 solution from the lecture, you should expect a validation set accuracy of about 0.89. To meet specifications, the validation set accuracy will need to be at least 0.93. It is possible to get an even higher accuracy, but 0.93 is the minimum for a successful project submission. 

There are various aspects to consider when thinking about this problem:

- Neural network architecture (is the network over or underfitting?)
- Play around preprocessing techniques (normalization, rgb to grayscale, etc)
- Number of examples per label (some have more than others).
- Generate fake data.

Here is an example of a [published baseline model on this problem](http://yann.lecun.com/exdb/publis/pdf/sermanet-ijcnn-11.pdf). It's not required to be familiar with the approach used in the paper but, it's good practice to try to read papers like these.

### Pre-process the Data Set (normalization, grayscale, etc.)

Minimally, the image data should be normalized so that the data has mean zero and equal variance. For image data, `(pixel - 128)/ 128` is a quick way to approximately normalize the data and can be used in this project. 

Other pre-processing steps are optional. You can try different techniques to see if it improves performance. 

Use the code cell (or multiple code cells, if necessary) to implement the first step of your project.


```python
from numpy import array
import numpy as np
gray1 = np.sum(X_train/3, axis=3)
gray2 = np.sum(X_valid/3, axis=3)
gray3 = np.sum(X_test/3, axis=3)

print(gray1.shape)

norm_gray1 = (gray1-128)/128
norm_gray2 = (gray2-128)/128
norm_gray3 = (gray3-128)/128

#norm_gray1 = array(norm_gray1).reshape(len(norm_gray1),32,32)
#norm_gray2 = array(norm_gray2).reshape(len(norm_gray2),32,32)
#norm_gray3 = array(norm_gray3).reshape(len(norm_gray3),32,32)

#index = random.randint(0, norm_gray1.shape[0])
#print(index, norm_gray1.shape)
#image = plt.imshow(norm_gray1[index], cmap="gray")

gallery(norm_gray3, 1, 10)
```

    (34799, 32, 32)
    1 38 33 11 38 18 12 25 35 12 


![png](output_11_1.png)


### Model Architecture


```python
### Basic Lenet
import tensorflow as tf
from tensorflow.contrib.layers import flatten

def LeNet(x):    
    # Arguments used for tf.truncated_normal, randomly defines variables for the weights and biases for each layer
    mu = 0
    sigma = 0.1
    
    # SOLUTION: Layer 1: Convolutional. Input = 32x32x1. Output = 28x28x6.
    conv1_W = tf.Variable(tf.truncated_normal(shape=(5, 5, 1, 6), mean = mu, stddev = sigma))
    conv1_b = tf.Variable(tf.zeros(6))
    conv1   = tf.nn.conv2d(x, conv1_W, strides=[1, 1, 1, 1], padding='VALID') + conv1_b

    # SOLUTION: Activation.
    conv1 = tf.nn.relu(conv1)

    # SOLUTION: Pooling. Input = 28x28x6. Output = 14x14x6.
    conv1 = tf.nn.max_pool(conv1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    # SOLUTION: Layer 2: Convolutional. Output = 10x10x16.
    conv2_W = tf.Variable(tf.truncated_normal(shape=(5, 5, 6, 16), mean = mu, stddev = sigma))
    conv2_b = tf.Variable(tf.zeros(16))
    conv2   = tf.nn.conv2d(conv1, conv2_W, strides=[1, 1, 1, 1], padding='VALID') + conv2_b
    
    # SOLUTION: Activation.
    conv2 = tf.nn.relu(conv2)

    # SOLUTION: Pooling. Input = 10x10x16. Output = 5x5x16.
    conv2 = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    # SOLUTION: Flatten. Input = 5x5x16. Output = 400.
    fc0   = flatten(conv2)
    
    # SOLUTION: Layer 3: Fully Connected. Input = 400. Output = 120.
    fc1_W = tf.Variable(tf.truncated_normal(shape=(400, 120), mean = mu, stddev = sigma))
    fc1_b = tf.Variable(tf.zeros(120))
    fc1   = tf.matmul(fc0, fc1_W) + fc1_b
    
    # SOLUTION: Activation.
    fc1    = tf.nn.relu(fc1)

    # SOLUTION: Layer 4: Fully Connected. Input = 120. Output = 84.
    fc2_W  = tf.Variable(tf.truncated_normal(shape=(120, 84), mean = mu, stddev = sigma))
    fc2_b  = tf.Variable(tf.zeros(84))
    fc2    = tf.matmul(fc1, fc2_W) + fc2_b
    
    # SOLUTION: Activation.
    fc2    = tf.nn.relu(fc2)

    # SOLUTION: Layer 5: Fully Connected. Input = 84. Output = 10.
    fc3_W  = tf.Variable(tf.truncated_normal(shape=(84, 43), mean = mu, stddev = sigma))
    fc3_b  = tf.Variable(tf.zeros(43))
    logits = tf.matmul(fc2, fc3_W) + fc3_b
    
    return logits
```


```python
### AlexNet

def AlexNet(x):    
    mu = 0
    sigma = 0.1
    
    # Layer 1: Convolutional. Input = 32x32x1. Output = 30x30x64.
    conv1_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 1, 64), mean = mu, stddev = sigma))
    conv1_b = tf.Variable(tf.zeros(64))
    conv1   = tf.nn.conv2d(x, conv1_W, strides=[1, 1, 1, 1], padding='VALID') + conv1_b

    # Pooling. Output = 14x14x64
    conv1 = tf.nn.max_pool(conv1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')
    
    # Activation.
    conv1 = tf.nn.relu(conv1)

    # Layer 2: Convolutional. Input = 14x14x64. Output = 12x12x64.
    conv2_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 64, 64), mean = mu, stddev = sigma))
    conv2_b = tf.Variable(tf.zeros(64))
    conv2   = tf.nn.conv2d(conv1, conv2_W, strides=[1, 1, 1, 1], padding='VALID') + conv2_b
        
    # Pooling. Output = 6x6x64
    conv2 = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    # Activation.
    conv2 = tf.nn.relu(conv2)
        
    # Flatten. Input = 6x6x64. Output = 2304.
    fc0   = flatten(conv2)
    
    # Layer 3: Fully Connected. Input = 2304. Output = 800.
    fc1_W = tf.Variable(tf.truncated_normal(shape=(2304, 800), mean = mu, stddev = sigma))
    fc1_b = tf.Variable(tf.zeros(800))
    fc1   = tf.matmul(fc0, fc1_W) + fc1_b
    
    # Activation.
    fc1    = tf.nn.relu(fc1)
    #fc1 = tf.nn.dropout(fc1, keep_prob) 

    # Layer 4: Fully Connected. Input = 800. Output = 120.
    fc2_W  = tf.Variable(tf.truncated_normal(shape=(800, 120), mean = mu, stddev = sigma))
    fc2_b  = tf.Variable(tf.zeros(120))
    fc2    = tf.matmul(fc1, fc2_W) + fc2_b
    
    # Activation.
    fc2    = tf.nn.relu(fc2)
    #fc2 = tf.nn.dropout(fc2, keep_prob) 

    # Layer 4: Fully Connected. Input = 120. Output = 43.
    fc3_W  = tf.Variable(tf.truncated_normal(shape=(120, 43), mean = mu, stddev = sigma))
    fc3_b  = tf.Variable(tf.zeros(43))
    logits = tf.matmul(fc2, fc3_W) + fc3_b

    return logits
```

### Train, Validate and Test the Model

A validation set can be used to assess how well the model is performing. A low accuracy on the training and validation
sets imply underfitting. A high accuracy on the training set but low accuracy on the validation set implies overfitting.


```python
### Train your model here.
### Calculate and report the accuracy on the training and validation set.
### Once a final model architecture is selected, 
### the accuracy on the test set should be calculated and reported as well.
### Feel free to use as many code cells as needed.

from numpy import array
from sklearn.utils import shuffle

assert len(X_train)==len(y_train)==len(size_train)==len(crd_train)
assert len(X_valid)==len(y_valid)==len(size_valid)==len(crd_valid)
assert len(X_test)==len(y_test)==len(size_test)==len(crd_test)
assert len(norm_gray1)==len(y_train)

X_train = norm_gray1
X_valid = norm_gray2

X_train, y_train = shuffle(X_train, y_train) #File check
EPOCHS = 15
BATCH_SIZE = 128

x = tf.placeholder(tf.float32, (None, 32, 32, 1))
y = tf.placeholder(tf.int32, (None))
keep_prob = tf.placeholder(tf.float32)
one_hot_y = tf.one_hot(y, 43)

rate = 0.001

logits = AlexNet(x)
cross_entropy = tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_y, logits=logits)
loss_operation = tf.reduce_mean(cross_entropy)
optimizer = tf.train.AdamOptimizer(learning_rate = rate)
training_operation = optimizer.minimize(loss_operation)

### Model Evaluation
correct_prediction = tf.equal(tf.argmax(logits, 1), tf.argmax(one_hot_y, 1))
accuracy_operation = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
#saver = tf.train.Saver()

def evaluate(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE]
        accuracy = sess.run(accuracy_operation, feed_dict={x: batch_x, y: batch_y, keep_prob: 1.0})
        total_accuracy += (accuracy * len(batch_x))
    return total_accuracy / num_examples

```


```python
### Train
import matplotlib.pyplot as plt

X_train = array(X_train).reshape(len(X_train),32,32,1)
X_valid = array(X_valid).reshape(len(X_valid),32,32,1)

#X_train = array(norm_gray1).reshape(len(norm_gray1),32,32,1)
#X_valid = array(norm_gray2).reshape(len(norm_gray2),32,32,1)
#X_test = array(norm_gray3).reshape(len(norm_gray3),32,32,1)

saver = tf.train.Saver()
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    num_examples = len(X_train)
    val_acc=[]
    print("Training...")
    for i in range(EPOCHS):
        for offset in range(0, num_examples, BATCH_SIZE):
            end = offset + BATCH_SIZE
            batch_x, batch_y = X_train[offset:end], y_train[offset:end]
            sess.run(training_operation, feed_dict={x: batch_x, y: batch_y})
            
        validation_accuracy = evaluate(X_valid, y_valid)
        print("EPOCH {} ...".format(i+1), end=" ")
        print("Validation Accuracy = {:.3f}".format(validation_accuracy))
        val_acc.append(validation_accuracy)
        
    saver.save(sess, './model.ckpt')
    print("Model saved")
        
plt.figure(figsize=(8, 3))
plt.plot(range(0, EPOCHS), val_acc)
```

    Training...
    EPOCH 1 ... Validation Accuracy = 0.855
    EPOCH 2 ... Validation Accuracy = 0.883
    EPOCH 3 ... Validation Accuracy = 0.903
    EPOCH 4 ... Validation Accuracy = 0.916
    EPOCH 5 ... Validation Accuracy = 0.928
    EPOCH 6 ... Validation Accuracy = 0.921
    EPOCH 7 ... Validation Accuracy = 0.930
    EPOCH 8 ... Validation Accuracy = 0.934
    EPOCH 9 ... Validation Accuracy = 0.943
    EPOCH 10 ... Validation Accuracy = 0.954
    EPOCH 11 ... Validation Accuracy = 0.934
    EPOCH 12 ... Validation Accuracy = 0.953
    EPOCH 13 ... Validation Accuracy = 0.920
    EPOCH 14 ... Validation Accuracy = 0.945
    EPOCH 15 ... Validation Accuracy = 0.958
    Model saved





    [<matplotlib.lines.Line2D at 0x7fd87d45e8d0>]




![png](output_18_2.png)



```python
from numpy import array
X_test = array(norm_gray3).reshape(len(norm_gray3),32,32,1)
assert len(X_test)==len(y_test)
#print(len(np.unique(y_test)), X_test.shape)

saver = tf.train.Saver()
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    saver.restore(sess, './model.ckpt')
    test_acc = evaluate(X_test, y_test)
    print("Test Accuracy = {:.3f}".format(test_acc))
```

    INFO:tensorflow:Restoring parameters from ./model.ckpt
    Test Accuracy = 0.937


---

## Step 3: Test a Model on New Images

To give yourself more insight into how your model is working, download at least five pictures of German traffic signs from the web and use your model to predict the traffic sign type.

You may find `signnames.csv` useful as it contains mappings from the class id (integer) to the actual sign name.

### Load and Output the Images


```python
### Load the images and plot them here.
### Feel free to use as many code cells as needed.

import os, sys
from os import listdir
import numpy as np
import cv2
import matplotlib.pyplot as plt

size = (32,32)
path = './images-cropped/'
img = np.zeros((6,32,32,3))
i = 0

for file in os.listdir(path):
    print(file, i)    
    tmp = cv2.imread(path+file)
    tmp = cv2.resize(tmp, size)
    b,g,r = cv2.split(tmp)
    rgb = cv2.merge([r,g,b])
    img[i] = rgb  
    i += 1
    
print(np.shape(img))
img = np.array(img, dtype=np.float32)

plt.figure(figsize=(12, 8))
for i in range(6):
    grid = plt.subplot(2, 3, i+1)
    grid.imshow(img[i])
    
plt.show()

#Pre-process
gray4 = np.sum(img/3, axis=3)
norm_gray4 = (gray4-128)/128
```

    slippery.JPG 0
    nopass35.JPG 1
    priority.jpg 2
    speed80.JPG 3
    stop.JPG 4
    roundabout.JPG 5
    (6, 32, 32, 3)



![png](output_22_1.png)


### Predict the Sign Type for Each Image


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.

import csv
signs = []
with open('signnames.csv', 'rt') as csvfile:
    reader = csv.DictReader(csvfile, delimiter=',')
    for row in reader:
        signs.append((row['SignName']))

X_test_new = array(norm_gray4).reshape(len(norm_gray4),32,32,1)

def test(X_data, sess):
    sign = sess.run(tf.argmax(logits, 1), feed_dict={x: X_data, keep_prob: 1.0})
    return sign

with tf.Session() as sess:
    saver.restore(sess, './model.ckpt')
    y=test(X_test_new, sess)

for i in range(6):
    plt.subplot(2, 3, i+1)
    plt.imshow(img[i]) 
    plt.title(signs[y[i]])
    plt.axis('off')
plt.show()
```

    INFO:tensorflow:Restoring parameters from ./model.ckpt



![png](output_24_1.png)


### Analyze Performance

The result is not 100% consistent in every run, but the prediction usually gets 3~4 signs correctly out of 6.
Thus, it would be safe to say the accuracy is somewhere 50~70%.
Above result is actually luckier than usual, classified 4 signs correctly, yield accuracy of 67%.

Also, two wrong classified signs were close enough, 
"No passing" instead of "No passing for 3.5ton" and 
"speed limit 60" instead of "speed limit 80."

One thing to notice is, 
both failed ones were cropped out from the same picture and were not from standard signs but from LED signs.


### Output Top 5 Softmax Probabilities For Each Image Found on the Web

For each of the new images, print out the model's softmax probabilities to show the **certainty** of the model's predictions (limit the output to the top 5 probabilities for each image). [`tf.nn.top_k`](https://www.tensorflow.org/versions/r0.12/api_docs/python/nn.html#top_k) could prove helpful here. 

The example below demonstrates how tf.nn.top_k can be used to find the top k predictions for each image.

`tf.nn.top_k` will return the values and indices (class ids) of the top k predictions. So if k=3, for each sign, it'll return the 3 largest probabilities (out of a possible 43) and the correspoding class ids.

Take this numpy array as an example. The values in the array represent predictions. The array contains softmax probabilities for five candidate images with six possible classes. `tf.nn.top_k` is used to choose the three classes with the highest probability:

```
# (5, 6) array
a = np.array([[ 0.24879643,  0.07032244,  0.12641572,  0.34763842,  0.07893497,
         0.12789202],
       [ 0.28086119,  0.27569815,  0.08594638,  0.0178669 ,  0.18063401,
         0.15899337],
       [ 0.26076848,  0.23664738,  0.08020603,  0.07001922,  0.1134371 ,
         0.23892179],
       [ 0.11943333,  0.29198961,  0.02605103,  0.26234032,  0.1351348 ,
         0.16505091],
       [ 0.09561176,  0.34396535,  0.0643941 ,  0.16240774,  0.24206137,
         0.09155967]])
```

Running it through `sess.run(tf.nn.top_k(tf.constant(a), k=3))` produces:

```
TopKV2(values=array([[ 0.34763842,  0.24879643,  0.12789202],
       [ 0.28086119,  0.27569815,  0.18063401],
       [ 0.26076848,  0.23892179,  0.23664738],
       [ 0.29198961,  0.26234032,  0.16505091],
       [ 0.34396535,  0.24206137,  0.16240774]]), indices=array([[3, 0, 5],
       [0, 1, 4],
       [0, 5, 1],
       [1, 3, 5],
       [1, 4, 3]], dtype=int32))
```

Looking just at the first row we get `[ 0.34763842,  0.24879643,  0.12789202]`, you can confirm these are the 3 largest probabilities in `a`. You'll also notice `[3, 0, 5]` are the corresponding indices.


```python
### Print out the top five softmax probabilities for the predictions on the German traffic sign images found on the web. 
### Feel free to use as many code cells as needed.

import tensorflow as tf
from numpy import array
    
def test(X_data, sess):
    sess.run(tf.global_variables_initializer())
    prob = sess.run(tf.nn.softmax(logits), feed_dict={x: X_data, keep_prob: 1.0})    
    top = tf.nn.top_k(prob, k=5)
    return sess.run(top)

saver = tf.train.Saver()
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    saver.restore(sess, './model.ckpt')
    top = test(X_test_new, sess)

#sess = tf.Session()
#print(test(X_test_new, sess))

plt.figure(figsize=(12, 16))
for i in range(6):
    plt.subplot(6, 2, 2*i+1)
    plt.imshow(img[i]) 
    plt.title(i)
    plt.axis('off')
    plt.subplot(6, 2, 2*i+2)
    print(top.values[i], top.indices[i])
    
    plt.barh(np.arange(5), top.values[i])
    val = [signs[j] for j in top.indices[i]]
    plt.yticks(np.arange(5), val)
plt.show()
```

    INFO:tensorflow:Restoring parameters from ./model.ckpt
    [ 0.21838632  0.1683901   0.13082337  0.06417026  0.05072438] [19 29 18 20 37]
    [ 0.1847122   0.10347389  0.09927614  0.07841742  0.07393947] [29 19 14 18 42]
    [ 0.1882793   0.10990912  0.10937683  0.0896071   0.08062494] [18 29 19 35 14]
    [ 0.15861748  0.12535882  0.11640382  0.0846433   0.07534718] [19 14 29 42 18]
    [ 0.180904    0.0971111   0.07219674  0.07164107  0.06864091] [29 18 33 19 14]
    [ 0.17539303  0.08610147  0.07213514  0.06418073  0.04981668] [18  2 19 12 14]



![png](output_29_1.png)


### Project Writeup

Once you have completed the code implementation, document your results in a project writeup using this [template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) as a guide. The writeup can be in a markdown or pdf file. 

> **Note**: Once you have completed all of the code implementations and successfully answered each question above, you may finalize your work by exporting the iPython Notebook as an HTML document. You can do this by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission.

---

## Step 4 (Optional): Visualize the Neural Network's State with Test Images

 This Section is not required to complete but acts as an additional excersise for understaning the output of a neural network's weights. While neural networks can be a great learning device they are often referred to as a black box. We can understand what the weights of a neural network look like better by plotting their feature maps. After successfully training your neural network you can see what it's feature maps look like by plotting the output of the network's weight layers in response to a test stimuli image. From these plotted feature maps, it's possible to see what characteristics of an image the network finds interesting. For a sign, maybe the inner network feature maps react with high activation to the sign's boundary outline or to the contrast in the sign's painted symbol.

 Provided for you below is the function code that allows you to get the visualization output of any tensorflow weight layer you want. The inputs to the function should be a stimuli image, one used during training or a new one you provided, and then the tensorflow variable name that represents the layer's state during the training process, for instance if you wanted to see what the [LeNet lab's](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) feature maps looked like for it's second convolutional layer you could enter conv2 as the tf_activation variable.

For an example of what feature map outputs look like, check out NVIDIA's results in their paper [End-to-End Deep Learning for Self-Driving Cars](https://devblogs.nvidia.com/parallelforall/deep-learning-self-driving-cars/) in the section Visualization of internal CNN State. NVIDIA was able to show that their network's inner weights had high activations to road boundary lines by comparing feature maps from an image with a clear path to one without. Try experimenting with a similar test to show that your trained network's weights are looking for interesting features, whether it's looking at differences in feature maps from images with or without a sign, or even what feature maps look like in a trained network vs a completely untrained one on the same sign image.

<figure>
 <img src="visualize_cnn.png" width="380" alt="Combined Image" />
 <figcaption>
 <p></p> 
 <p style="text-align: center;"> Your output should look something like this (above)</p> 
 </figcaption>
</figure>
 <p></p> 



```python
### Visualize your network's feature maps here.
### Feel free to use as many code cells as needed.

# image_input: the test image being fed into the network to produce the feature maps
# tf_activation: should be a tf variable name used during your training procedure that represents the calculated state of a specific weight layer
# activation_min/max: can be used to view the activation contrast in more detail, by default matplot sets min and max to the actual min and max values of the output
# plt_num: used to plot out multiple different weight feature map sets on the same block, just extend the plt number for each new feature map entry
import tensorflow as tf
x = tf.placeholder(tf.float32, (None, 32, 32, 1))
one_hot_y = tf.one_hot(y, 43)


def outputFeatureMap(image_input, tf_activation, activation_min=-1, activation_max=-1 ,plt_num=1):
    # Here make sure to preprocess your image_input in a way your network expects
    # with size, normalization, ect if needed
    # image_input =
    # Note: x should be the same name as your network's tensorflow data placeholder variable
    # If you get an error tf_activation is not defined it may be having trouble accessing the variable from inside a function
    activation = tf_activation.eval(session=sess,feed_dict={x : image_input})
    featuremaps = activation.shape[3]
    plt.figure(plt_num, figsize=(15,15))
    for featuremap in range(featuremaps):
        plt.subplot(6,8, featuremap+1) # sets the number of feature maps to show on each row and column
        plt.title('FeatureMap ' + str(featuremap)) # displays the feature map number
        if activation_min != -1 & activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin =activation_min, vmax=activation_max, cmap="gray")
        elif activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmax=activation_max, cmap="gray")
        elif activation_min !=-1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin=activation_min, cmap="gray")
        else:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", cmap="gray")
            
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    outputFeatureMap(X_test_new, x,-2,2,1)
    outputFeatureMap(X_test_new, x,-1,2,2)
    outputFeatureMap(X_test_new, x,-2,4,3)
```


![png](output_33_0.png)



![png](output_33_1.png)



![png](output_33_2.png)



```python

```
